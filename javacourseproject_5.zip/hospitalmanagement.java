import olddoc.olddoctor;
import newdoctor.docpat;
import oldpatient.oldpat;
import newpatient.newpat;
import labandstaff.labstaff;
import ArogyasriandBilling.arogyabilling;
import java.util.Scanner;
class hospital
{
static   //Static block
{
System.out.println("\t\t\t\tGLOBAL HEALTH CARE HOSPITALS");
}
void message()
{
System.out.println("\t\t\t\tWe care for you most. ");
}
}
class hospital2 extends hospital   //
{
void message()   //overriding
{
super.message();  //super at method level
System.out.println("\t\t\t\tSubedari,Hanamakonda,Warangal,Telangana,506001 ");
}
}
class hospitalmanagement
{
public static void main(String args[])
{
hospital2 H2=new hospital2();
H2.message();
Scanner sc=new Scanner(System.in);
while(true)
{
System.out.println("MAIN MENU");
System.out.println("1.Old doctor details");
System.out.println("2.Entering new doctor details");
System.out.println("3.Patient details");
System.out.println("4.New patient details");
System.out.println("5.Lab details");
System.out.println("6.Staff details");
System.out.println("7.Arogyasri details");
System.out.println("8.Billing");
System.out.println("9.Exit");
System.out.println("-----------------------------------------------------");
System.out.println("Enter your choice:");
int c=sc.nextInt();
if(c==9)
{
System.out.println("THANK YOU");
break;
}
switch(c)
{
case 1:
System.out.println("\t\t\t\t---------*********OLD DOCTORS DETAILS*********---------");
 olddoctor o1=new olddoctor("DR.chander","A21",43,"Male","9600250432","Hanamkonda","General","OP","10am-2:30pm",140000);
o1.displayolddoctordetails();
olddoctor o2=new olddoctor("DR.spoorthi","A22",36,"Female","7688345210","Hanamkonda","ENT","OP","10am-2:30pm",95000);
o2.displayolddoctordetails();
olddoctor o3=new olddoctor("DR.Rama","A23",51,"Female","8096543800","Hyderabad","Gynaecologist","OP&Surgen","11am-3pm",240000);
o3.displayolddoctordetails();
olddoctor o4=new olddoctor("DR.Vijay","A24",62,"Male","9866200901","Warangal","Orthopedic","OP&Surgen","11am-2:30pm",295000);
o4.displayolddoctordetails();
olddoctor o5=new olddoctor("DR.Shiva","A25",48,"Male","9234260345","Hyderabad","Dermatologist","OP","11am-2:30pm",180000);
o5.displayolddoctordetails();
olddoctor o6=new olddoctor("DR.Mamatha","A26",38,"Female","9542564310","Hyderabad","Cardiologist","OP&Surgen","11am-1:30pm",240000);
o6.displayolddoctordetails();
break;
case 2:
System.out.println("\t\t\t\t\t**********NEW DOCTORS DATA********** ");
int i,n;
docpat D=new docpat();
System.out.println("Hello..how many new doctors details you need to enter:");
n=sc.nextInt();
for (i = 1; i <= n; i++)
{
          System.out.println(" Enter doctor "+i+"details") ;
        D.doc();
System.out.println("++++++++DOCTOR "+i+" DETAILS++++++++++");
        D.showdoc();
}
break;
case 3:
System.out.println("\t\t\t\t---------*********OLD PATIENT DETAILS*********---------");
 oldpat p1=new oldpat("Alluri.karthik","p10","Male",25,"9876321007","Warangal","Dengue","DR.chander","204","yes");
p1.showoldpat();
oldpat p2=new oldpat("Dhonthi.sumaja","p210","Female",35,"9000586652","Hanamkonda","Tonsillitis","DR.spoorthi","not_Admited","No");
p2.showoldpat();
oldpat p3=new oldpat("Vemula.Ashok","p13","Male",47,"7784300651","Ragunathpalley","Fever","DR.chander","not_Admited","No");
p3.showoldpat();
oldpat p4=new oldpat("Kundhur.Srilatha","p205","Female",68,"9755331090","Hanamkonda","BoneFracture","DR.Vijay","OrthoICU","yes");
p4.showoldpat();
oldpat p5=new oldpat("Chinthala.vijay","p263","Male",45,"9553754805","Warangal","HeartStroke","DR.Mamatha","cardioICU","yes");
p5.showoldpat();
oldpat p6=new oldpat("Gayam.Tara","p264","Female",75,"8008957208","Narsampet","SkinRash(Fungal-Infection)","DR.Ramesh","not_Admited","No");
p6.showoldpat();
break;
case 4:
System.out.println("\t-----------*****NEW PATIENTS DATA*****-------------");
int j,x;
newpat p=new newpat();
System.out.println("Hello..how many new patients details you need to enter:");
x=sc.nextInt();
for (j = 1; j<= x; j++)
{
   
          System.out.println(" Enter Patient "+j+" details") ;
        p.pat();
     System.out.println("++++++++++++PATIENT "+j+" DETAILS++++++++++++++");
        p.showpat();
}
break;
case 5:
System.out.println("\t-----------*****LAB DETAILS*****-------------");
new labstaff();
break;
case 6:
System.out.println("\t\t\t\t---------*********STAFF DETAILS*********---------");
labstaff s1=new labstaff("Allam.pooja","Female","9854217650","Managing Director","9am","6pm",80000);
s1.showstaff();
labstaff s2=new labstaff("Dharapu.Sreeja","Female","9700882211","Nurse","9am","6pm",25000);
s2.showstaff();
labstaff s3=new labstaff("Gangasani.Satya","Male","7855761290","Hospital_Pharmacy","9:30am","10pm",20000);
s3.showstaff();
labstaff s4=new labstaff("Angirekula.Sudeer","Male","8003461195","Radiologist","9am","7:30pm",15000);
s4.showstaff();
labstaff s5=new labstaff("Akula.Dheeraj","Male","9876231100","Ambulance_Driver","9am","8:30pm",10000);
s5.showstaff();
labstaff s6=new labstaff("Aaluri.Deepika","Female","8900563211","Receptionist","9am","7:30pm",20000);
s6.showstaff();
break;
case 7:
new arogyabilling();
break;
case 8:
System.out.println("+++++++++++BILLING DETAILS++++++++++++");
new arogyabilling(20);
break;
}
}
}
}
